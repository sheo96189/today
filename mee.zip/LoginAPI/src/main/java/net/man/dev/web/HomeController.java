package net.man.dev.web;

import javax.servlet.http.HttpServletRequest;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import net.man.dev.dao.LoginRecordRepository;
import net.man.dev.dao.loginRecord;
//import net.man.dev.dao.userSignupRepository;

@Controller
public class HomeController 
{
	@Autowired
	LoginRecordRepository lr;
	//userSignupRepository pl;
	
	@RequestMapping("/login")
	public String save()
	{
		return "start";
		
	}
	@RequestMapping("/signup")
	public String signup(HttpServletRequest request) 
	{
		lr.saveUser(request.getParameter("f_name"), request.getParameter("f_email"), request.getParameter("f_password"), request.getParameter("Conf_Pws"));
//		 
//		//ModelAndView mv1 = new ModelAndView();
//		System.out.println("-------" +request.getParameter("f_name"));
//		System.out.println("-------" +request.getParameter("f_email"));
//		System.out.println("-------" +request.getParameter("f_password"));
//		System.out.println("-------" +request.getParameter("Conf_Pws"));
//		
//		boolean b = lr.saveUser(request.getParameter("f_name"), request.getParameter("f_email"), request.getParameter("f_password"), request.getParameter("Conf_Pws"));
//		
//		
////	boolean b = lr.validateuserSignup(request.getParameter("f_name"), request.getParameter("f_email"), request.getParameter("f_password"), request.getParameter("Conf_Pws"));			
////		if(b)
////		{
////			System.out.println("Signup Successfully");
////			mv1.setViewName("Success");
////			
////		}else
////		{
////		System.out.println("Some thing Went Wrong");
////		//mv1.setView("Fail");
////		}
		return "Sign_up";
	}
//	@RequestMapping(value = "/signup", method = RequestMethod.POST)
//	public String adduser(@RequestBody loginRecord lr)
//	{
//		
//		
//		return "Sign_up";
//	}
	@RequestMapping("/validate")
	public ModelAndView validate(HttpServletRequest request)
	{
		ModelAndView mv = new ModelAndView();
		System.out.println("---------------"+request.getParameter("uname"));
		System.out.println("---------------"+request.getParameter("password"));
			boolean a=lr.validateLogin(request.getParameter("uname"), request.getParameter("password"));
			if(a) {
				System.out.println("Login Successfully");
				mv.setViewName("Success");
			}
			else
			{
				System.out.println("Oops Something Went Wrong !!! ");
				mv.setViewName("Fail");
			}
		return mv;
		
	}
	
	@RequestMapping("/forgetpassword")
	public String forgetpassword() 
	{
		return "forget_password";
	}
	
	

}
