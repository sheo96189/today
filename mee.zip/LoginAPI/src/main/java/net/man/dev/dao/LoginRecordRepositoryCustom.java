package net.man.dev.dao;

public interface LoginRecordRepositoryCustom 
{
	boolean validateLogin(String uName,String Pwd);
	
	boolean saveUser(String f_name, String f_email, String f_password, String Conf_Pws);
	
	//boolean forgetpassword (String f_name, String f_email);
	
	
	
}


