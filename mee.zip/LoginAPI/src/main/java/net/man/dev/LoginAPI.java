package net.man.dev;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;

@SpringBootApplication
@Component
@EnableAutoConfiguration
public class LoginAPI {

	public static void main(String[] args)
	{

		SpringApplication app = new SpringApplication(LoginAPI.class);
		app.run(args);
	}

}
