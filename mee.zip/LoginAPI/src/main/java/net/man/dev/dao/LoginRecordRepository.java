package net.man.dev.dao;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface LoginRecordRepository extends MongoRepository<LoginRecordRepository, String> , LoginRecordRepositoryCustom 
{

	

	
	

}
