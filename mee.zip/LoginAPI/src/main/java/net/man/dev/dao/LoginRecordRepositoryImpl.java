package net.man.dev.dao;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.*;

public class LoginRecordRepositoryImpl implements LoginRecordRepositoryCustom {
	@Autowired
	MongoTemplate mongotemplate;
	List<loginRecord> test = null;
	@Autowired
	loginRecord loginRecord;

	public boolean validateLogin(String uName, String Pwd) {
		System.out.println("-->>>>>>>>>>>>>>>>>>>");
		boolean flag = false;
		try {
			Query query = new Query();

			query.addCriteria(Criteria.where("email").is(uName).and("password").is(Pwd));
			test = mongotemplate.find(query, loginRecord.class);

			if (test.size() > 0) {
				System.out.println("Get Data From MONGO :: " + test + "--- With ID : " + test.get(0).getId());
				flag = true;
			}

			else
				flag = false;
		} catch (Exception Ex) {
			System.out.println("Exception : " + Ex);
		}
		return flag;
	}

	public boolean saveUser(String f_name, String f_email, String f_password, String Conf_Pws) {
		boolean flag = false;
		{
			loginRecord.setName(f_name);
			loginRecord.setEmail(f_email);
			loginRecord.setPassword(f_password);
			
			loginRecord.setCreated_at(new Date());
			//loginRecord.setCreated_at(System.currentTimeMillis() + "");
			loginRecord.setUpdated_at(new Date());

			// Query query = new Query();
			// query.addCriteria(Criteria("name").is(f_name).and("email").is(f_email).and("password").is(f_password).and("Password").is(Conf_Pws));
			mongotemplate.save(loginRecord);

		}
		return flag;
	}
	
//	public boolean forgetpassword( String )
//	{
//		boolean flag = false;
//		{
//			
//		}
//		return flag;
//	}

}
