function myFun()
{
	var a = document.name1.uname.value;
	if(a.indexOf('@') <= 0)
	{
		document.getElementById("Message").innerHTML="** Invalide @ Position";
		return false;
	}
	if(a.indexOf() = 0)
	{
		document.getElementById("Message").innerHTML="** Fill Proper Email ID";
	}
	if( a.charAt(a.length-4)!='.') 
	{
		document.getElementById("Message").innerHTML="** Invalide  Dot Position";
		return false;
		
	}
	if(a.charAt(a.length-3)!='.')
	{
		document.getElementById("Message").innerHTML="** Invalide  Dot Position";
		return false;
		
	}
	
}

