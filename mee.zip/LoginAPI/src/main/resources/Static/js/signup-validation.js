function signupvalidation()
{
	//collect Data as a variable
	var name1 = document.getElementById("f_name").value;
	var email1 = document.getElementById("email_id").value;
	var pw1 = document.getElementById("password_id").value
	var pw2 = document.getElementById("Conf_Pwsid").value
	var em = pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$";	
	
	//Check Empty
	if(name1 =="")
	{
		document.getElementById("nMessage").innerHTML="**Fill the first Name";
		return false;
		
	}
	if(!isNaN(name1))
	{
		document.getElementById("nMessage").innerHTML="**Only Character are allowed";
		return false;
	}
	if(!isNaN(email1))
	{
		document.getElementById("eMessage").innerHTML="**Only Charecter and valid Email Address are allowed ";
		return false;
	}
	if(email1 == em)
	{
		document.getElementById("eMessage").innerHTML="** Password must be in correct formate";
		return false;
	}
	if(pw1=="")
	{
		document.getElementById("pMessage").innerHTML="**Enter The Password Please";
		return false;
	}
	if(pw2=="")
	{
		document.getElementById("cMessage").innerHTML="**Enter The Password Please";
		return false;
	}
	if(pw1.length < 6)
	{
		document.getElementById("pMessage").innerHTML="**Password length must be atlist 6 characters";
		return false;
	}
	if(pw1!=pw2)
	{
		document.getElementById("cMessage").innerHTML="Password are not same";
		return false;
	}
	
}
